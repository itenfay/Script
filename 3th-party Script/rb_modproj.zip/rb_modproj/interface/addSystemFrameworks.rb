
def addSystemFrameworks(project, target, frameworks)
    require File.dirname(__FILE__)+'/../lib/xcodeproj'
    
    proj = Xcodeproj::Project.open(project)
    targetNode = proj.targets.first
    if proj.targets.first.name != target then
        for i in proj.targets
            if i.name == target then
                targetNode = i
                break
            end
        end
    end
    
    totalArrayAll = frameworks.split(',') #dylib and frameworks,去重前的
    totalArray = [] #去重后的
    
    for framework in totalArrayAll
        isExist = false
        for frameworkExist in targetNode.frameworks_build_phases.file_display_names
            if frameworkExist.scan(/\.[^\.]+$/)[0] == nil then
                next;
            end
            frameworkExistName = File.basename(frameworkExist, frameworkExist.scan(/\.[^\.]+$/)[0])
            frameworkName = File.basename(framework, framework.scan(/\.[^\.]+$/)[0])
            if frameworkExistName == frameworkName then
                isExist = true
                break
            end
        end
        if not isExist then
            totalArray << framework
        end
    end
    
    libArray = []
    frameworkArray = []
    for file in totalArray
        suffix = file.scan(/\.[^\.]+$/)[0]
        if suffix == '.dylib' then
            libArray << file
        elsif suffix == '.tbd' then
            libArray << file
        elsif suffix == '.framework' then
            frameworkArray << file
        end
    end
    
    targetNode.add_system_framework(frameworkArray)
    targetNode.add_system_library(libArray)

    proj.save
end

addSystemFrameworks(ARGV[0], ARGV[1], ARGV[2])
