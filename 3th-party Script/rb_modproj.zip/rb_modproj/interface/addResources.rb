
def addResources(project, target, resources) #只针对修改工程时候调用, 只针对第三方库和资源以及源文件，非系统库
    require File.dirname(__FILE__)+'/../lib/xcodeproj'


    proj = Xcodeproj::Project.open(project)
    targetNode = proj.targets.first
    if proj.targets.first.name != target then
        for i in proj.targets
            if i.name == target then
                targetNode = i
                break
            end
        end
    end

    group = proj.main_group.find_subpath(File.join('QuickSDK'), true)
    group.set_source_tree('SOURCE_ROOT')
    
    resArray = resources.split(',')
    refArray = []
    sourceArray = []
    for res in resArray
        ref = group.new_reference(res, 'SOURCE_ROOT')
        suffix = res.scan(/\.[^\.]+$/)[0]
        if suffix == '.a' || suffix == '.framework' || suffix == '.dylib' || suffix == '.tbd' then
            targetNode.frameworks_build_phase.add_file_reference(ref, true)
        elsif suffix == '.mm' then
            sourceArray << ref
        else
            refArray << ref
        end
    end
    targetNode.add_resources(refArray)
    targetNode.add_file_references(sourceArray)
    
    proj.save
end
    
addResources(ARGV[0], ARGV[1], ARGV[2])